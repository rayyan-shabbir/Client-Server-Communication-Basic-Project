
    btnSendMessage.grid(row=2, co